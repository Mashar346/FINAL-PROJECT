# Tic-Tac-Toe with AI

A fun, quick Tic-Tac-Toe game built with Pygame—complete with a button you can beat (or not) depending on the difficulty.

## What’s Inside

* **Play vs. AI**: You’re “X,” the computer’s “O.”
* **Three Difficulty Levels**:

  * **EASY**: AI picks moves at random.
  * **MEDIUM**: Half the time it’s smart, half random.
  * **HARD**: AI always tries to win or block you.
* **Simple Interface**: Click squares to place your “X.” The board resets after each round.
* **Score Keeper**: Tracks wins, losses, and draws.
* **Reset & Quit Buttons**: Start fresh whenever you like.

## How to Run

1. Install Pygame if you haven’t already:

   ```bash
   pip install pygame
   ```
2. Save the code as `tic_tac_toe_ai.py`.
3. In your terminal (or command prompt), navigate to the folder and run:

   ```bash
   python tic_tac_toe_ai.py
   ```
4. Click on an empty square to make your move. The AI will take its turn after a short pause.

## Controls

* **Click on a square**: Place your “X.”
* **EASY / MEDIUM / HARD buttons**: Change the AI’s difficulty on the fly.
* **RESET GAME**: Clears scores and board.
* **QUIT**: Exit the game.

## AI Cheat Sheet

* **EASY**: Purely random moves.
* **MEDIUM**: 50/50 chance to play like HARD or random.
* **HARD**:
  1. Try to win if possible.
  2. Block you if you’re about to win.
  3. Take center if it’s free.
  4. Pick a corner.
  5. Finally, pick any open spot.

## Quick Tips

* If you notice the AI blocking you or grabbing the center a lot, that’s “HARD” doing its thing.
* Want a chill game? Switch to EASY or MEDIUM.
* You can change colors, board size, or button styles in the code’s top section—everything’s clearly labeled.
